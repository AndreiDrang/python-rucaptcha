from CommonCaptcha import CommonCaptcha
from RecaptchaV2 import ReCaptcha
from RucaptchaControl import RucaptchaControl
from config import url_request, url_response