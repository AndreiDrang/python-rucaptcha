# Сервер для отправки данных
url_request = "http://2captcha.com/in.php"
# Сервер для получения ответа
url_response = "http://2captcha.com/res.php"
# ключ приложения
app_key = "1899"