# Сервер для отправки данных
url_request_2captcha = "http://2captcha.com/in.php"
# Сервер для получения ответа
url_response_2captcha = "http://2captcha.com/res.php"
# Сервер для отправки данных
url_request_rucaptcha = "http://rucaptcha.com/in.php"
# Сервер для получения ответа
url_response_rucaptcha = "http://rucaptcha.com/res.php"
# ключ приложения
app_key = "1899"